package com.entities;

public class UserLocationAggregate {

}
