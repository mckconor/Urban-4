package com.entities;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

public class UserLocationsList {


	@Getter @Setter
	private List<UserLocation> locations;
	
}
